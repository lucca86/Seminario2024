package org.lucca86.java.jdbc.modelo;

public class SubCategoria {
    private Integer idSubCategoria;
    //private Integer Categoria_idCategoria;
    private String nombre;
    private String Descricion;

    public int getIdSubCategoria() {
        return idSubCategoria;
    }

    public void setIdSubCategoria(Integer idSubCategoria) {
        this.idSubCategoria = idSubCategoria;
    }

//    public Integer getCategoria_idCategoria() {
//        return Categoria_idCategoria;
//    }
//
//    public void setCategoria_idCategoria(Integer categoria_idCategoria) {
//        Categoria_idCategoria = categoria_idCategoria;
//    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescricion() {
        return Descricion;
    }

    public void setDescricion(String descricion) {
        Descricion = descricion;
    }

    @Override
    public String toString() {
        return  "idSubCategoria=" + idSubCategoria +
                ", nombre='" + nombre + '\'' +
                ", Descricion='" + Descricion + '\'';
    }
}
