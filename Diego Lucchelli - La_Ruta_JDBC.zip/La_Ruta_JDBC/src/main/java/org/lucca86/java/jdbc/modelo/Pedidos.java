package org.lucca86.java.jdbc.modelo;


import java.util.Date;

public class Pedidos {
    private Integer idPedido;
    private Integer idMesa;
    private Integer clientes_idClientes;
    private Date fecha;
    private Enum estado;


    @Override
    public String toString() {
        return "idPedido=" + idPedido +
                ", idMesa=" + idMesa +
                ", clientes_idClientes=" + clientes_idClientes +
                ", fecha=" + fecha +
                ", estado=" + estado;
    }

    public Pedidos() {
    }

    public Pedidos(Integer idPedido, Integer idMesa, Integer clientes_idClientes, Date fecha, Enum estado) {
        this.idPedido = idPedido;
        this.idMesa = idMesa;
        this.clientes_idClientes = clientes_idClientes;
        this.fecha = fecha;
        this.estado = estado;
    }

    public Integer getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(Integer idPedido) {
        this.idPedido = idPedido;
    }

    public Integer getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(Integer idMesa) {
        this.idMesa = idMesa;
    }

    public Integer getClientes_idClientes() {
        return clientes_idClientes;
    }

    public void setClientes_idClientes(Integer clientes_idClientes) {
        this.clientes_idClientes = clientes_idClientes;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Enum getEstado() {
        return estado;
    }

    public void setEstado(Enum estado) {
        this.estado = estado;
    }
}
