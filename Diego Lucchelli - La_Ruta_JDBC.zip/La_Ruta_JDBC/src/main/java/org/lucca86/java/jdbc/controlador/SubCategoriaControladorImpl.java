package org.lucca86.java.jdbc.controlador;


import org.lucca86.java.jdbc.modelo.SubCategoria;
import org.lucca86.java.jdbc.util.ConexionBaseDatos;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SubCategoriaControladorImpl implements Controlador <SubCategoria> {
    private Connection getConnection() throws SQLException {
        return ConexionBaseDatos.getInstance();
    }


    //************* Listar todas las SubCategorías **************//
    @Override
    public List<SubCategoria> listar() {
        List<SubCategoria> subCategorias = new ArrayList<>();
        try(Statement stmt = getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM subcategorias ORDER BY idSubCategoria ASC")) {
            while (rs.next()) {
                SubCategoria sc = crearSubCategoria(rs);
                subCategorias.add(sc); // Pasamos la subCategoria al ArrayList
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return subCategorias;
    }

    //************* Listar 1 producto por Id **************//
    @Override
    public SubCategoria porId(Integer id) {
        SubCategoria subCategoria = null;

        try(PreparedStatement stmt = getConnection().prepareStatement("SELECT p.*, sc.nombre AS NomSubCategoria FROM " +
                "productos AS p INNER JOIN subcategorias AS sc ON (p.idSubCategoria = sc.idSubCategoria) WHERE idProducto = ? ") ) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()) {
                subCategoria = crearSubCategoria(rs);
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return subCategoria;
    }

    //************* Crear un proveedor **************//
    @Override
    public void guardar(SubCategoria proveedor) {
        String sql;
        sql = "INSERT INTO proveedores (nombres, descripcion, precioUnitario, idSubCategoria, stock, iva, idProveedor) VALUES(?,?,?,?,?,?,?)";

//        try(PreparedStatement stmt = getConnection().prepareStatement(sql)){
//            stmt.setString(1, proveedor.getRazonSocial());
//            stmt.setString(2, proveedor.);
//            stmt.setString(2, proveedor.getDescripcion());
//            stmt.setDouble(3, proveedor.getPrecioUnitario());
//            stmt.setInt(4, proveedor.getSubCategoria().getIdSubCategoria());
//            stmt.setDouble(5, proveedor.getStock());
//            stmt.setDouble(6, proveedor.getIva());
//            stmt.setInt(7, proveedor.getIdProveedor());
//
//            stmt.executeUpdate();
//            } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
    }

    //************* Actualizar un producto **************//
    @Override
    public void actualizar(SubCategoria proveedor) {
//        String sql;
//        sql = "UPDATE productos SET nombre=?, descripcion=?, precioUnitario=? WHERE idProducto=?";
//
//        try(PreparedStatement stmt = getConnection().prepareStatement(sql)){
//            stmt.setString(1, producto.getNombre());
//            stmt.setString(2, producto.getDescripcion());
//            stmt.setDouble(3, producto.getPrecioUnitario());
//            if (producto.getIdProducto() != null && producto.getIdProducto() > 0) {
//                stmt.setInt(4, producto.getIdProducto());
//            }
//            stmt.setInt(4, producto.getSubCategoria().getIdSubCategoria());
//            stmt.setDouble(5, producto.getStock());
//            stmt.setDouble(6, producto.getIva());
//            stmt.setInt(7, producto.getIdProveedor());

//            stmt.executeUpdate();
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
    }

    @Override
    public void eliminar(Integer id) {
        try(PreparedStatement stmt = getConnection().prepareStatement("DELETE FROM proveedores WHERE idProvedor=?")){
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private SubCategoria crearSubCategoria(ResultSet rs) throws SQLException {
        SubCategoria sc = new SubCategoria();
        sc.setIdSubCategoria(rs.getInt("idSubCategoria"));
        sc.setNombre(rs.getString("nombre"));
        sc.setDescricion(rs.getString("descripcion"));

        return sc;
    }
}
