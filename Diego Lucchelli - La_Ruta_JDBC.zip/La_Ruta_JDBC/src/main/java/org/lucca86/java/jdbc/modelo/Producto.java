package org.lucca86.java.jdbc.modelo;

public class Producto {
    private Integer idProducto;
    private String nombre;
    private String descripcion;
    private SubCategoria subCategoria;
    private Double precioUnitario;
    private Double stock;
    private Double iva;
    private Integer idProveedor;


    @Override
    public String toString() {
        return idProducto +
                " | " + nombre +
                " | " + descripcion +
                " | " + subCategoria.getNombre() +
                " | " + precioUnitario +
                " | " + stock +
                " | " + iva +
                " | " + idProveedor;
    }

    public Producto() {
    }

    public Producto(Integer idProducto, String nombre, String descripcion, SubCategoria subCategoria, Double precioUnitario, Double stock, Double iva, Integer idProveedor) {
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.subCategoria = subCategoria;
        this.precioUnitario = precioUnitario;
        this.stock = stock;
        this.iva = iva;
        this.idProveedor = idProveedor;
    }

    public Integer getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Integer idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public SubCategoria getSubCategoria() {
        return subCategoria;
    }

    public void setSubCategoria(SubCategoria subCategoria) {
        this.subCategoria = subCategoria;
    }

    public Double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(Double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public Double getStock() {
        return stock;
    }

    public void setStock(Double stock) {
        this.stock = stock;
    }

    public Double getIva() {
        return iva;
    }

    public void setIva(Double iva) {
        this.iva = iva;
    }

    public Integer getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(Integer idProveedor) {
        this.idProveedor = idProveedor;
    }
}
