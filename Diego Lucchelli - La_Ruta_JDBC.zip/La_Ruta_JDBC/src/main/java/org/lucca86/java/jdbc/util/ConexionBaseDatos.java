package org.lucca86.java.jdbc.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBaseDatos {
    private static String url = "jdbc:mysql://localhost:3306/larutadb?serverTimezone=America/Buenos_Aires";
    private static String username = "root";
    private static String password = "lens0426";
    private static Connection connection;

    public static Connection getInstance() throws SQLException {
        if(connection == null) {
            connection = DriverManager.getConnection(url, username, password);
        }

        return connection;
    }
}
