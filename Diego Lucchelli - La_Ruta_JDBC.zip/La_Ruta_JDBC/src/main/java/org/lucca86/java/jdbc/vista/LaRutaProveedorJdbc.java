package org.lucca86.java.jdbc.vista;

import org.lucca86.java.jdbc.controlador.Controlador;
import org.lucca86.java.jdbc.controlador.ProductoControladorImpl;
import org.lucca86.java.jdbc.controlador.ProveedorControladorImpl;
import org.lucca86.java.jdbc.modelo.Producto;
import org.lucca86.java.jdbc.modelo.Proveedor;

import javax.swing.*;

public class LaRutaProveedorJdbc {
     public static void main() {

        int opcion;
                do {
                    String input = JOptionPane.showInputDialog(
                            "=== Menú Proveedores ===\n" +
                                    "1. Listar\n" +
                                    "2. Listar por ID\n" +
                                    "3. Crear\n" +
                                    "4. Editar\n" +
                                    "5. Eliminar\n" +
                                    "6. MENU PRINCIPAL\n" +
                                    "Elige una opción (1-6):");

                    opcion = Integer.parseInt(input);

                    switch (opcion) {
                        case 1:
                            // JOptionPane.showMessageDialog(null, "Has elegido la Opción 1");
                                Controlador<Proveedor> controlador = new ProveedorControladorImpl();
                                System.out.println("============= Listar ==============");
                                controlador.listar().forEach(System.out::println); //Listamos todos los proveedores
                            break;
                        case 2:
                            // JOptionPane.showMessageDialog(null, "Has elegido la Opción 2");
                                String id = JOptionPane.showInputDialog("Ingresa un ID:");
                                int valor = Integer.parseInt(id);
                                System.out.println("============= Listar por ID ==============");
                                Controlador<Proveedor> listId = new ProveedorControladorImpl();
                                System.out.println(listId.porId(valor)); // Muestra el proveedor con id(valor)
                            break;
                        case 3:
                            //JOptionPane.showMessageDialog(null, "Has elegido la Opción 3");
                                Controlador<Proveedor> insert = new ProveedorControladorImpl();
                                Proveedor proveedor = new Proveedor();
                                String nom = JOptionPane.showInputDialog("Ingresa el nombre:");
                                proveedor.setNombre(nom);
                                String rs = JOptionPane.showInputDialog("Ingresa la Razón Social:");
                                proveedor.setRazonSocial(rs);
                                String cu = JOptionPane.showInputDialog("Ingresa la CUIT:");
                                proveedor.setCuit(cu);
                                String ci = JOptionPane.showInputDialog("Ingresa la condición de IVA (ID):");
                                int condIvaId = Integer.parseInt(ci);
                                proveedor.setCondIva_idcondIva(condIvaId);
                                insert.guardar(proveedor);
                                System.out.println("Proveedor creado con éxito");
                                insert.listar().forEach(System.out::println); //Listamos todos los prodcutos
                            break;
                        case 4:
                            //JOptionPane.showMessageDialog(null, "Has elegido la Opción 4");
                            Controlador<Proveedor> editar = new ProveedorControladorImpl();
                            Proveedor editaProv = new Proveedor();
                            String idEditar = JOptionPane.showInputDialog("Ingresa el ID:");
                            int valorEditar = Integer.parseInt(idEditar);
                            editaProv.setIdProveedor(valorEditar);
                            String nomEdit = JOptionPane.showInputDialog("Ingresa el nombre:");
                            editaProv.setNombre(nomEdit);
                            String rsEdit = JOptionPane.showInputDialog("Ingresa la Razón Social:");
                            editaProv.setRazonSocial(rsEdit);
                            String cuEdit = JOptionPane.showInputDialog("Ingresa la CUIT:");
                            editaProv.setCuit(cuEdit);
                            editar.actualizar(editaProv);
                            System.out.println("Proveedor modificado con éxito");
                            editar.listar().forEach(System.out::println); //Listamos todos los proveedores
                            break;
                        case 5:
                            // JOptionPane.showMessageDialog(null, "Has elegido la Opción 5");
                            Controlador<Proveedor> borrar = new ProveedorControladorImpl();
                            System.out.println("============= Eliminar Proveedor ==============");
                            String idBorrar = JOptionPane.showInputDialog("Ingresa el ID a eliminar:");
                            int valorBorrar = Integer.parseInt(idBorrar);
                            borrar.eliminar(valorBorrar);
                            System.out.println("Proveedor " + valorBorrar + " eliminado con éxito");
                            //controlador.listar().forEach(System.out::println); //Listamos todos los prodcutos
                            break;
                        case 6:
                            //JOptionPane.showMessageDialog(null, "¡Hasta luego!");
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Opción no válida. Inténtalo de nuevo.");
                    }

                } while (opcion != 6);
            }
        }

//
//
//
//
//        try (Connection conn = ConexionBaseDatos.getInstance()) {
//            Controlador<Producto> controlador = new ProductoControladorImpl();
//            System.out.println("============= Listar ==============");
//            controlador.listar().forEach(System.out::println); //Listamos todos los prodcutos
//
//            System.out.println("============= Listar por ID ==============");
//            System.out.println(controlador.porId(2)); // Lista el producto con id(2)
//
//            System.out.println("============= Insertar Producto ==============");
//            Producto producto = new Producto();
//            producto.setNombre("Aquarius Mandarina x 1.5l");
//            producto.setDescripcion("producto descartable");
//            producto.setPrecioUnitario(890.00);
//            producto.setStock(12.00);
//            producto.setIva(21.00);
//            producto.setIdProveedor(2);
//            SubCategoria subCategoria = new SubCategoria();
//            subCategoria.setIdSubCategoria(2);
//            producto.setSubCategoria(subCategoria);
//            controlador.guardar(producto);
//            System.out.println("Producto creado con éxito");
//            controlador.listar().forEach(System.out::println); //Listamos todos los prodcutos
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//    }
//}
