package org.lucca86.java.jdbc.vista;

import javax.swing.*;

public class LaRuta {
    public static void main(String[] args) {

        int opcion;
        do {
            String input = JOptionPane.showInputDialog(
                    "#### MENU PRINCIPAL ####\n" +
                            "1. Pedidos\n" +
                            "2. Productos\n" +
                            "3. Proveedores\n" +
                            "4. Clientes\n" +
                            "5. Categorías\n" +
                            "6. SubCategorias\n" +
                            "7. SALIR\n" +
                            "Elige una opción (1-7):");

            opcion = Integer.parseInt(input);

            switch (opcion) {
                case 1:
                    JOptionPane.showMessageDialog(null, "¡Proximamente... en construcción!");
                    break;
                case 2:
                        LaRutaProductoJdbc.main();
                    break;
                case 3:
                        LaRutaProveedorJdbc.main();
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "¡Proximamente... en construcción!");

                    break;
                case 5:
                    JOptionPane.showMessageDialog(null, "¡Proximamente... en construcción!");

                    break;
                case 6:
                    LaRutaSubCategoriaJdbc.main();
                    break;
                case 7:
                    JOptionPane.showMessageDialog(null, "¡Hasta luego!");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Inténtalo de nuevo.");
            }

        } while (opcion != 7);
    }
}
