package org.lucca86.java.jdbc.controlador;

import org.lucca86.java.jdbc.modelo.Producto;
import org.lucca86.java.jdbc.modelo.SubCategoria;
import org.lucca86.java.jdbc.util.ConexionBaseDatos;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductoControladorImpl implements Controlador <Producto> {
    private Connection getConnection() throws SQLException {
        return ConexionBaseDatos.getInstance();
    }


    //************* Listar todos los productos **************//
    @Override
    public List<Producto> listar() {
        List<Producto> productos = new ArrayList<>();
        try(Statement stmt = getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT p.*, sc.nombre AS NomSubCategoria FROM productos AS p " +
                    "INNER JOIN subcategorias AS sc ON (p.idSubCategoria = sc.idSubCategoria) ORDER BY idProducto ASC")) {
            while (rs.next()) {
                Producto p = crearProducto(rs);
                productos.add(p); // Pasamos el producto a el ArrayList
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return productos;
    }

    //************* Listar 1 producto por Id **************//
    @Override
    public Producto porId(Integer id) {
        Producto producto = null;

        try(PreparedStatement stmt = getConnection().prepareStatement("SELECT p.*, sc.nombre AS NomSubCategoria FROM " +
                "productos AS p INNER JOIN subcategorias AS sc ON (p.idSubCategoria = sc.idSubCategoria) WHERE idProducto = ? ") ) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()) {
                producto = crearProducto(rs);
            }
            rs.close();
        } catch (SQLException e) {

            throw new RuntimeException(e);
        }
        return producto;
    }

    //************* Crear un producto **************//
    @Override
    public void guardar(Producto producto) {
        String sql;
        sql = "INSERT INTO productos (nombre, descripcion, precioUnitario, idSubCategoria, stock, iva, idProveedor) VALUES(?,?,?,?,?,?,?)";

        try(PreparedStatement stmt = getConnection().prepareStatement(sql)){
            stmt.setString(1, producto.getNombre());
            stmt.setString(2, producto.getDescripcion());
            stmt.setDouble(3, producto.getPrecioUnitario());
            stmt.setInt(4, producto.getSubCategoria().getIdSubCategoria());
            stmt.setDouble(5, producto.getStock());
            stmt.setDouble(6, producto.getIva());
            stmt.setInt(7, producto.getIdProveedor());

            stmt.executeUpdate();
            } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //************* Actualizar un producto **************//
    @Override
    public void actualizar(Producto producto) {
        String sql;
        sql = "UPDATE productos SET nombre=?, descripcion=?, precioUnitario=? WHERE idProducto=?";

        try(PreparedStatement stmt = getConnection().prepareStatement(sql)){
            stmt.setString(1, producto.getNombre());
            stmt.setString(2, producto.getDescripcion());
            stmt.setDouble(3, producto.getPrecioUnitario());
            if (producto.getIdProducto() != null && producto.getIdProducto() > 0) {
                stmt.setInt(4, producto.getIdProducto());
            }
//            stmt.setInt(4, producto.getSubCategoria().getIdSubCategoria());
//            stmt.setDouble(5, producto.getStock());
//            stmt.setDouble(6, producto.getIva());
//            stmt.setInt(7, producto.getIdProveedor());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void eliminar(Integer id) {
        try(PreparedStatement stmt = getConnection().prepareStatement("DELETE FROM productos WHERE idProducto=?")){
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private Producto crearProducto(ResultSet rs) throws SQLException {
        Producto p = new Producto();
        p.setIdProducto(rs.getInt("idProducto"));
        p.setNombre(rs.getString("nombre"));
        p.setDescripcion(rs.getString("descripcion"));
        p.setPrecioUnitario(rs.getDouble("precioUnitario"));
        p.setStock(rs.getDouble("stock"));
        p.setIva(rs.getDouble("iva"));
        p.setIdProveedor(rs.getInt("idProveedor"));
        SubCategoria subCategoria = new SubCategoria();
        subCategoria.setIdSubCategoria(rs.getInt("idSubCategoria"));
        subCategoria.setNombre(rs.getString("NomSubCategoria"));
        p.setSubCategoria(subCategoria);
        return p;
    }
}
