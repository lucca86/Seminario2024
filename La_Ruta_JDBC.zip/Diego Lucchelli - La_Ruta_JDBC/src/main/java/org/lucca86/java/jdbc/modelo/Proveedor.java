package org.lucca86.java.jdbc.modelo;

import java.util.Objects;

public class Proveedor {
    private Integer idProveedor;
    private String nombre;
    private String razonSocial;
    private String cuit;
    private Integer condIva_idcondIva;

    public Proveedor() {

    }

    public Proveedor(Integer idProveedor, String nombre, String razonSocial, String cuit, Integer condIva_idcondIva) {
        this.idProveedor = idProveedor;
        this.nombre = nombre;
        this.razonSocial = razonSocial;
        this.cuit = cuit;
        this.condIva_idcondIva = condIva_idcondIva;
    }


    @Override
    public String toString() {
        return "ID=" + idProveedor +
                ", Nombre='" + nombre + '\'' +
                ", Razon Social='" + razonSocial + '\'' +
                ", CUIT='" + cuit + '\'' +
                ", CondIva=" + condIva_idcondIva;
    }


    public Integer getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(Integer idProveedor) {
        this.idProveedor = idProveedor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public Integer getCondIva_idcondIva() {
        return condIva_idcondIva;
    }

    public void setCondIva_idcondIva(Integer condIva_idcondIva) {
        this.condIva_idcondIva = condIva_idcondIva;
    }

    //    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        Persona persona = (Persona) o;
//        return Objects.equals(idPersona, persona.idPersona);
//    }
}
