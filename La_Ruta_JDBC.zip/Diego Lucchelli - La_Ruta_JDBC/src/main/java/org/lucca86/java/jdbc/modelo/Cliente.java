package org.lucca86.java.jdbc.modelo;

public class Cliente {
    private Integer idCliente;
    private String nombres;
    private String apellidos;
    private String email;
    private String cuit;
    private Integer condIva_idcondIva;


    @Override
    public String toString() {
        return  "idCliente=" + idCliente +
                ", nombres='" + nombres + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", email='" + email + '\'' +
                ", cuit='" + cuit + '\'' +
                ", condIva_idcondIva=" + condIva_idcondIva;
    }

    public Cliente() {
    }

    public Cliente(Integer idCliente, String nombres, String apellidos, String email, String cuit, Integer condIva_idcondIva) {
        this.idCliente = idCliente;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.email = email;
        this.cuit = cuit;
        this.condIva_idcondIva = condIva_idcondIva;
    }

    public Integer getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public Integer getCondIva_idcondIva() {
        return condIva_idcondIva;
    }

    public void setCondIva_idcondIva(Integer condIva_idcondIva) {
        this.condIva_idcondIva = condIva_idcondIva;
    }
}
