package org.lucca86.java.jdbc.controlador;


import org.lucca86.java.jdbc.modelo.Proveedor;
import org.lucca86.java.jdbc.util.ConexionBaseDatos;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProveedorControladorImpl implements Controlador <Proveedor> {
    private Connection getConnection() throws SQLException {
        return ConexionBaseDatos.getInstance();
    }


    //************* Listar todos los proveedores **************//
    @Override
    public List<Proveedor> listar() {
        List<Proveedor> proveedores = new ArrayList<>();
        try(Statement stmt = getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM proveedores ORDER BY idProveedor ASC")) {
            while (rs.next()) {
                Proveedor pv = crearProveedor(rs);
                proveedores.add(pv); // Pasamos el proveedor al ArrayList
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return proveedores;
    }

    //************* Listar 1 proveedor por Id **************//
    @Override
    public Proveedor porId(Integer id) {
        Proveedor proveedor = null;

        try(PreparedStatement stmt = getConnection().prepareStatement("SELECT * FROM proveedores WHERE idProveedor = ? ") ) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()) {
                proveedor = crearProveedor(rs);
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return proveedor;
    }

    //************* Crear un proveedor **************//
    @Override
    public void guardar(Proveedor proveedor) {
        String sql;
        sql = "INSERT INTO proveedores (nombre, razonSocial, cuit, condIva_idcondIva) VALUES(?,?,?,?)";

        try(PreparedStatement stmt = getConnection().prepareStatement(sql)){
            stmt.setString(1, proveedor.getNombre());
            stmt.setString(2, proveedor.getRazonSocial());
            stmt.setString(3, proveedor.getCuit());
            stmt.setInt(4, proveedor.getCondIva_idcondIva());

            stmt.executeUpdate();
            } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //************* Actualizar un proveedor **************//
    @Override
    public void actualizar(Proveedor proveedor) {
        String sql;
        sql = "UPDATE proveedor SET nombre=?, razonSocial=?, cuit=? WHERE idProveedor=?";

        try(PreparedStatement stmt = getConnection().prepareStatement(sql)){
            stmt.setString(1, proveedor.getNombre());
            stmt.setString(2, proveedor.getRazonSocial());
            stmt.setString(3, proveedor.getCuit());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void eliminar(Integer id) {
        try(PreparedStatement stmt = getConnection().prepareStatement("DELETE FROM proveedores WHERE idProveedor=?")){
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private Proveedor crearProveedor(ResultSet rs) throws SQLException {
        Proveedor pv = new Proveedor();
        pv.setIdProveedor(rs.getInt("idProveedor"));
        pv.setNombre(rs.getString("nombre"));
        pv.setRazonSocial(rs.getString("razonSocial"));
        pv.setCuit(rs.getString("cuit"));
        pv.setCondIva_idcondIva(rs.getInt("condIva_idcondIva"));

        return pv;
    }
}
