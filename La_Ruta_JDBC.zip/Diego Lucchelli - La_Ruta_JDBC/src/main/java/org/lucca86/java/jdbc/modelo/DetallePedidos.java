package org.lucca86.java.jdbc.modelo;

public class DetallePedidos {
    private Integer idDetallePedidos;
    private Integer pedidos_idPedidos;
    private Integer productos_idProductos;
    private Integer cantidad;


    @Override
    public String toString() {
        return "idDetallePedidos=" + idDetallePedidos +
                ", pedidos_idPedidos=" + pedidos_idPedidos +
                ", productos_idProductos=" + productos_idProductos +
                ", cantidad=" + cantidad;
    }

    public DetallePedidos() {
    }

    public DetallePedidos(Integer idDetallePedidos, Integer pedidos_idPedidos, Integer productos_idProductos, Integer cantidad) {
        this.idDetallePedidos = idDetallePedidos;
        this.pedidos_idPedidos = pedidos_idPedidos;
        this.productos_idProductos = productos_idProductos;
        this.cantidad = cantidad;
    }

    public Integer getIdDetallePedidos() {
        return idDetallePedidos;
    }

    public void setIdDetallePedidos(Integer idDetallePedidos) {
        this.idDetallePedidos = idDetallePedidos;
    }

    public Integer getPedidos_idPedidos() {
        return pedidos_idPedidos;
    }

    public void setPedidos_idPedidos(Integer pedidos_idPedidos) {
        this.pedidos_idPedidos = pedidos_idPedidos;
    }

    public Integer getProductos_idProductos() {
        return productos_idProductos;
    }

    public void setProductos_idProductos(Integer productos_idProductos) {
        this.productos_idProductos = productos_idProductos;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }
}
