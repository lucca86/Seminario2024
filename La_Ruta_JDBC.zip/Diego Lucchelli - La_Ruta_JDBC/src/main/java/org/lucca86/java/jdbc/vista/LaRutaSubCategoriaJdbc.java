package org.lucca86.java.jdbc.vista;

import org.lucca86.java.jdbc.controlador.Controlador;
import org.lucca86.java.jdbc.controlador.ProductoControladorImpl;
import org.lucca86.java.jdbc.controlador.SubCategoriaControladorImpl;
import org.lucca86.java.jdbc.modelo.Producto;
import org.lucca86.java.jdbc.modelo.SubCategoria;

import javax.swing.*;

public class LaRutaSubCategoriaJdbc {
     public static void main() {

        int opcion;
                do {
                    String input = JOptionPane.showInputDialog(
                            "=== Menú SubCategorias ===\n" +
                                    "1. Listar\n" +
                                    "2. Listar por ID\n" +
                                    "3. Crear\n" +
                                    "4. Editar\n" +
                                    "5. Eliminar\n" +
                                    "6. MENU PRINCIPAL\n" +
                                    "Elige una opción (1-6):");

                    opcion = Integer.parseInt(input);

                    switch (opcion) {
                        case 1:
                            // JOptionPane.showMessageDialog(null, "Has elegido la Opción 1");
                                Controlador<SubCategoria> controlador = new SubCategoriaControladorImpl();
                                System.out.println("============= Listar ==============");
                                controlador.listar().forEach(System.out::println); //Listamos todos los proveedores
                            break;
                        case 2:
                            // JOptionPane.showMessageDialog(null, "Has elegido la Opción 2");
                                String id = JOptionPane.showInputDialog("Ingresa un valor:");
                                int valor = Integer.parseInt(id);
                                System.out.println("============= Listar por ID ==============");
                                Controlador<Producto> listId = new ProductoControladorImpl();
                                System.out.println(listId.porId(valor)); // Lista el producto con id(2)
                            break;
                        case 3:
                            //JOptionPane.showMessageDialog(null, "Has elegido la Opción 3");
                                Controlador<Producto> insert = new ProductoControladorImpl();
                                Producto producto = new Producto();
                                String nom = JOptionPane.showInputDialog("Ingresa el nombre:");
                                producto.setNombre(nom);
                                String desc = JOptionPane.showInputDialog("Ingresa la descripción:");
                                producto.setDescripcion(desc);
                                String pre = JOptionPane.showInputDialog("Ingresa el precio:");
                                Double preUn = Double.parseDouble(pre);
                                producto.setPrecioUnitario(preUn);
                                producto.setStock(12.00);
                                producto.setIva(21.00);
                                producto.setIdProveedor(2);
                                SubCategoria subCategoria = new SubCategoria();
                                subCategoria.setIdSubCategoria(2);
                                producto.setSubCategoria(subCategoria);
                                insert.guardar(producto);
                                System.out.println("Producto creado con éxito");
                                insert.listar().forEach(System.out::println); //Listamos todos los prodcutos
                            break;
                        case 4:
                            //JOptionPane.showMessageDialog(null, "Has elegido la Opción 3");
                            Controlador<Producto> editar = new ProductoControladorImpl();
                            Producto editaProd = new Producto();
                            //String idEditar = JOptionPane.showInputDialog("Ingresa un valor:");
                            //int valorEditar = Integer.parseInt(idEditar);
                            editaProd.setIdProducto(19);
                            String nomEdit = JOptionPane.showInputDialog("Ingresa el nombre:");
                            editaProd.setNombre(nomEdit);
                            String descEdit = JOptionPane.showInputDialog("Ingresa la descripción:");
                            editaProd.setDescripcion(descEdit);
                            String preEdit = JOptionPane.showInputDialog("Ingresa el precio:");
                            Double preUnEdit = Double.parseDouble(preEdit);
                            editaProd.setPrecioUnitario(preUnEdit);
                            //editaProd.setStock(12.00);
                            //editaProd.setIva(21.00);
                            //editaProd.setIdProveedor(2);
                            //SubCategoria subCategoria = new SubCategoria();
                            //subCategoria.setIdSubCategoria(2);
                            //editaProd.setSubCategoria(subCategoria);
                            editar.actualizar(editaProd);
                            System.out.println("Producto creado con éxito");
                            editar.listar().forEach(System.out::println); //Listamos todos los prodcutos
                            break;
                        case 5:
                            // JOptionPane.showMessageDialog(null, "Has elegido la Opción 4");
                            // Agrega aquí la lógica para la Opción 4
                            Controlador<Producto> borrar = new ProductoControladorImpl();
                            System.out.println("============= Eliminar Producto ==============");
                            String idBorrar = JOptionPane.showInputDialog("Ingresa un valor:");
                            int valorBorrar = Integer.parseInt(idBorrar);
                            borrar.eliminar(valorBorrar);
                            System.out.println("Producto " + valorBorrar + " eliminado con éxito");
                            //controlador.listar().forEach(System.out::println); //Listamos todos los prodcutos
                            break;
                        case 6:
                            //JOptionPane.showMessageDialog(null, "¡Hasta luego!");
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Opción no válida. Inténtalo de nuevo.");
                    }

                } while (opcion != 6);
            }
        }
