package org.lucca86.laruta.proveedor;

import org.lucca86.laruta.modelo.Proveedor;

import java.util.ArrayList;
import java.util.List;

public class ProveedorList implements CrudProveedor {

    private List<Proveedor> dataSource;

    public ProveedorList() {
        this.dataSource = new ArrayList<>();
    }

    @Override
    public List<Proveedor> listar() {
        return dataSource;
    }

    @Override
    public Proveedor porId(Integer idproveedor) {
        return null;
    }

    @Override
    public void crear(Proveedor proveedor) {
        this.dataSource.add(proveedor);
    }

    @Override
    public void editar(Proveedor proveedor) {

    }

    @Override
    public void eliminar(int idProveedor) {

    }
}
