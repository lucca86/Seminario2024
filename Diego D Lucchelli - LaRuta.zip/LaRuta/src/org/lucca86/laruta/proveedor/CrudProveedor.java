package org.lucca86.laruta.proveedor;

import org.lucca86.laruta.modelo.Proveedor;

import java.util.List;

public interface CrudProveedor {
    List<Proveedor> listar();
    Proveedor porId(Integer idproveedor);
    void crear(Proveedor cliente);
    void editar(Proveedor cliente);
    void eliminar(int idProveedor);
}
