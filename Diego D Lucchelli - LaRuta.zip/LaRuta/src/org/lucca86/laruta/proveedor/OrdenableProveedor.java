package org.lucca86.laruta.proveedor;

import org.lucca86.laruta.modelo.Proveedor;
import org.lucca86.laruta.producto.Orden;

import java.util.List;

public interface OrdenableProveedor {
    List<Proveedor> listar(String campo, Orden orden);
}
