package org.lucca86.laruta.producto;

import org.lucca86.laruta.modelo.Producto;

import java.util.List;

public interface OrdenableProducto {
    List<Producto> listar(String campo, Orden orden);
}

