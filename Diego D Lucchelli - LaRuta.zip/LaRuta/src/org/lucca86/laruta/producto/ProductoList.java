package org.lucca86.laruta.producto;

import org.lucca86.laruta.modelo.Producto;

import java.util.ArrayList;
import java.util.List;

public class ProductoList implements CrudProducto, OrdenableProducto{

    private List<Producto> dataSource;

    public ProductoList() {
        this.dataSource = new ArrayList<>();
    }

    @Override
    public List<Producto> listar() {
        return dataSource;
    }

    @Override
    public Producto porId(Integer idProducto) {
        Producto resultado = null;
        for (Producto prod: dataSource) {
            if(prod.getIdProducto() != null && prod.getIdProducto().equals(idProducto)) {
                resultado = prod;
                break;
            }
        }
        return resultado;
    }

    @Override
    public void crear(Producto producto) {
        this.dataSource.add(producto);
    }

    @Override
    public void editar(Producto producto) {
        Producto p = this.porId(producto.getIdProducto());
        p.setNombre(producto.getNombre());
        p.setPrecioUnitario(producto.getPrecioUnitario());
        p.setStock(producto.getStock());
    }

    @Override
    public void eliminar(Integer idProducto) {
        this.dataSource.remove(this.porId(idProducto));
    }

    @Override
    public List<Producto> listar(String campo, Orden dir) {
        List<Producto> listaOrdenada = new ArrayList<>(this.dataSource);
        listaOrdenada.sort((a, b) -> {
            int resultado = 0;
            if(dir == Orden.ASC){
                resultado = ordenar(campo, a, b);
            } else if(dir == Orden.DESC){
                resultado = ordenar(campo, b, a);
            }
            return resultado;
        });
        return listaOrdenada;
    }
//    @Override
//    public List<Cliente> listar(int desde, int hasta) {
//
//        return dataSource.subList(desde, hasta);
//    }

    public static int ordenar(String campo, Producto a, Producto b){
        int resultado = 0;
        switch (campo){
            case "id" ->
                    resultado = a.getIdProducto().compareTo(b.getIdProducto());
            case "nombre" ->
                    resultado = a.getNombre().compareTo(b.getNombre());
            case "precioUnitario" ->
                    resultado = a.getPrecioUnitario().compareTo(b.getPrecioUnitario());
            case "stock" ->
                    resultado = a.getStock().compareTo(b.getStock());
        }
        return resultado;
    }

}
