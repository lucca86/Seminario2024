package org.lucca86.laruta.producto;

public enum Orden {
    ASC, DESC
}
