package org.lucca86.laruta.producto;

import org.lucca86.laruta.modelo.Producto;

import java.util.List;

public interface CrudProducto {
    List<Producto> listar();
    Producto porId(Integer idProducto);
    void crear(Producto producto);
    void editar(Producto producto);
    void eliminar(Integer idProducto);
}
