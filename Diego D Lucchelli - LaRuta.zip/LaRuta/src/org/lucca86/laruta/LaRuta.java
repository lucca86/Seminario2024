package org.lucca86.laruta;

import org.lucca86.laruta.modelo.Producto;
import org.lucca86.laruta.modelo.Proveedor;
import org.lucca86.laruta.producto.*;
import org.lucca86.laruta.proveedor.*;

import javax.swing.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LaRuta {
    public static void main(String[] args) {

//        int opcionIndice = 0;
//
//        Map<String, Integer> operaciones = new HashMap();
//        operaciones.put("Crear productos", 1);
//        operaciones.put("Editar productos", 2);
//        operaciones.put("Listar", 3);
//        operaciones.put("Eliminar", 4);
//        operaciones.put("Salir", 5);
//
//        Object[] opArreglo = operaciones.keySet().toArray();
//
//        Object opcion = JOptionPane.showInputDialog(null,
//                "Seleccione un Operación",
//                "Mantenedor de Usuarios",
//                JOptionPane.INFORMATION_MESSAGE, null, opArreglo, opArreglo[0]);
//
//        if (opcion == null) {
//            JOptionPane.showMessageDialog(null, "Debe seleccionar una operación");
//        } else {
//            opcionIndice = operaciones.get(opcion.toString());
//
//            // usamos un switch para las distintas operaciones.

        CrudProveedor prov = new ProveedorList();
        CrudProducto prod = new ProductoList();

        System.out.println("===== Productos =====");
        prod.crear(new Producto(
                1,
                "Coca-cola 1.5 litros",
                "Descartable",
                "Bebidas sin alcohol",
                1530.00,
                10.00,
                21.00,
                1));

        prod.crear(new Producto(
                2,
                "Agua mineral 1 litro",
                "Descartable",
                "Bebidas sin alcohol",
                1220.00,
                15.00,
                21.00,
                2));

        prod.crear(new Producto(
                3,
                "Coca-cola 1 litro",
                "Retornable",
                "Bebidas sin alcohol",
                1120.00,
                12.00,
                21.00,
                1));

        prod.crear(new Producto(
                4,
                "Agua mineral con gas 1 litro",
                "Descartable",
                "Bebidas sin alcohol",
                1250.00,
                20.00,
                21.00,
                2));
        List<Producto> producto = prod.listar();
        producto.forEach(System.out::println);

        System.out.println("===== Editar: Producto editado =====");
        Producto xxActualizar = new Producto("Agua sin gas", 2300.00, 9.00);
        xxActualizar.setIdProducto(2);
        prod.editar(xxActualizar);
        Producto modif = prod.porId(2);
        System.out.println(modif);
        //((OrdenableProducto) prod).listar("nombre", Orden.ASC).forEach(System.out::println);


        prov.crear(new Proveedor(
                "RI",
                "20-20939426-0",
                "3794-331143",
                "San Martín 341",
                "sergio@correo.com",
                "Perez",
                "Sergio",
                1,
                "Refrescos del Litoral S.R.L."
        ));

        prov.crear(new Proveedor(
                "RI",
                "20-31295876-6",
                "3794-214578",
                "Belgrano 2241",
                "fernando@correo.com",
                "Alonso",
                "Fernando",
                2,
                "Alimentos Correntinos S.A."
        ));

        System.out.println("===== Listar Proveedor =====");
        List<Proveedor> proveedor = prov.listar();
        proveedor.forEach(System.out::println);

        System.out.println("===== Ordenar =====");
        List<Producto> productoOrdenAsc = ((OrdenableProducto) prod).listar("nombre", Orden.ASC);
        for (Producto p : productoOrdenAsc) {
            System.out.println(p);
        }

        System.out.println("===== Eliminar =====");
        //prod.eliminar(2);
        //prod.listar().forEach(System.out::println);
    }
}
