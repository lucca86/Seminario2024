package org.lucca86.laruta.modelo;

abstract public class Persona {
    protected Integer idPersona;
    protected String nombres;
    protected String apellido;
    protected String email;
    protected String direccion;
    protected String telefono;
    protected String cuit;
    protected String condIva;

    public Persona() {
    }

    public Persona(String condIva, String cuit, String telefono, String direccion, String email, String apellido, String nombres, Integer idPersona) {
        this();
        this.condIva = condIva;
        this.cuit = cuit;
        this.telefono = telefono;
        this.direccion = direccion;
        this.email = email;
        this.apellido = apellido;
        this.nombres = nombres;
        this.idPersona = idPersona;
    }

    public void setIdPersona(Integer idPersona) {
        this.idPersona = idPersona;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public void setCondIva(String condIva) {
        this.condIva = condIva;
    }

    abstract public void listar();
    abstract public void porId();
    abstract public void crear();
    abstract public void modificar();
    abstract public void eliminar();

}
