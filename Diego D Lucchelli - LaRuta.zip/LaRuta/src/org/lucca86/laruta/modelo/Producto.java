package org.lucca86.laruta.modelo;

import java.util.Objects;

public class Producto {
    private Integer idProducto;
    private String nombre;
    private String descripcion;
    private String subCategoria;
    private Double precioUnitario;
    private Double stock;
    private Double iva;
    private Integer idProveedor;

    public Producto() {

    }

    public Producto(String nombre, Double precioUnitario, Double stock) {
        this.nombre = nombre;
        this.precioUnitario = precioUnitario;
        this.stock = stock;
    }

    public Producto(Integer idProducto, String nombre, String descripcion, String subCategoria, Double precioUnitario, Double stock, Double iva, Integer idProveedor) {
        this();
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.subCategoria = subCategoria;
        this.precioUnitario = precioUnitario;
        this.stock = stock;
        this.iva = iva;
        this.idProveedor = idProveedor;

    }

    public Integer getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Integer idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getSubCategoria() {
        return subCategoria;
    }

    public void setSubCategoria(String subCategoria) {
        this.subCategoria = subCategoria;
    }

    public Double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(Double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public Double getStock() {
        return stock;
    }

    public void setStock(Double stock) {
        this.stock = stock;
    }

    public Double getIva() {
        return iva;
    }

    public void setIva(Double iva) {
        this.iva = iva;
    }

    public Integer getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(Integer idProveedor) {
        this.idProveedor = idProveedor;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "idProducto=" + idProducto +
                ", nombre='" + nombre + '\'' +
                //", descripcion='" + descripcion + '\'' +
                ", subCategoria='" + subCategoria + '\'' +
                ", precioUnitario=" + precioUnitario +
                ", stock=" + stock +
                //", iva=" + iva +
                ", idProveedor=" + idProveedor +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Producto producto = (Producto) o;
        return Objects.equals(idProducto, producto.idProducto);
    }
}
