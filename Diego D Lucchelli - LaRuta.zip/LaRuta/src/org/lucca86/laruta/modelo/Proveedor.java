package org.lucca86.laruta.modelo;

import java.util.ArrayList;
import java.util.Objects;

public class Proveedor extends Persona{

    private String razonSocial;

    public Proveedor(String condIva, String cuit, String telefono, String direccion, String email, String apellido, String nombres, Integer idPersona) {
        super(condIva, cuit, telefono, direccion, email, apellido, nombres, idPersona);
    }


    public Proveedor(String condIva, String cuit, String telefono, String direccion, String email, String apellido, String nombres, Integer idPersona, String razonSocial) {
        super(condIva, cuit, telefono, direccion, email, apellido, nombres, idPersona);
        this.razonSocial = razonSocial;
    }


    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }


    @Override
    public void crear() {

    }

    @Override
    public void porId() {

    }

    @Override
    public void listar() {

    }

    @Override
    public void modificar() {

    }

    @Override
    public void eliminar() {

    }

    @Override
    public String toString() {
        return "id=" + idPersona +
                ", nombres='" + nombres + '\'' +
                ", apellido='" + apellido + '\'' ;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Persona persona = (Persona) o;
        return Objects.equals(idPersona, persona.idPersona);
    }

}
